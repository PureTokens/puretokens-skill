# puretokens-locate-v1
[CmdletBinding()]
param(
  [Parameter(Position = 0, Mandatory = $true)]
  [ValidateSet("check", "init", "sync", "locate")]
  [string]$Command,
  [Parameter(Mandatory = $false)]
  [string]$Target,
  [Parameter(Mandatory = $false)]
  [ValidateSet("claude-code", "codex", "workbuddy", "gemini-cli", "grok-build", "opencode", "trae", "claude-desktop", "dsh-desktop", "zcode", "kimi-code", "qoder")]
  [Alias("Host")]
  [string]$HostId,
  [Parameter(Mandatory = $false)]
  [string]$Source
)

$ErrorActionPreference = "Stop"
$currentSkills = @("puretokens-balance", "puretokens-connection", "puretokens-models", "puretokens-image", "puretokens-video", "puretokens-update")
$retiredSkills = @("puretokens_media", "puretokens_balance", "puretokens_connection", "puretokens_models", "puretokens_image", "puretokens_video", "puretokens_update", "puretokens_get_balance", "puretokens_get_model_price", "puretokens_workbuddy_router")

function Fail([string]$Message) { throw "Pure Tokens Skill installer: $Message" }

# Only the verified native executor uses this launcher. No shell, window,
# elevation, credential argument or fallback launch is involved.
function Invoke-NativeExecutor([string]$Executable, [string[]]$ArgumentList) {
  $quoted = foreach ($argument in $ArgumentList) {
    if ($argument.Contains('"') -or $argument.Contains("`n") -or $argument.Contains("`r")) { Fail "invalid native executor argument" }
    # Windows command-line quoting: trailing backslashes must be doubled.
    '"' + [regex]::Replace($argument, '(\\+)$', '$1$1') + '"'
  }
  $start = New-Object System.Diagnostics.ProcessStartInfo
  $start.FileName = $Executable
  $start.Arguments = $quoted -join ' '
  $start.UseShellExecute = $false
  $start.CreateNoWindow = $true
  $start.RedirectStandardOutput = $true
  $start.RedirectStandardError = $true
  $start.RedirectStandardInput = $true
  $start.StandardOutputEncoding = New-Object System.Text.UTF8Encoding($false)
  $start.StandardErrorEncoding = New-Object System.Text.UTF8Encoding($false)
  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $start
  try {
    if (-not $process.Start()) { Fail "native executor could not start" }
    $process.StandardInput.Close()
    # Drain both pipes concurrently; errors cannot block behind a full pipe.
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    $timeoutMs = if ($ArgumentList[0] -eq "init") { 195000 } else { 30000 }
    if (-not $process.WaitForExit($timeoutMs)) {
      try { $process.Kill(); $null = $process.WaitForExit(5000) } catch { }
      Fail "native executor timed out; stop this installation attempt and report the stage; do not retry or modify the installer"
    }
    if (-not [System.Threading.Tasks.Task]::WaitAll([System.Threading.Tasks.Task[]]@($stdout, $stderr), 5000)) { Fail "native executor output was not available; stop without a fallback launcher" }
    $text = $stdout.GetAwaiter().GetResult()
    $null = $stderr.GetAwaiter().GetResult()
    return [PSCustomObject]@{ ExitCode = $process.ExitCode; Output = $text }
  } catch { Fail "native executor launch, timeout or output capture failed; stop this attempt and report the stage; do not probe, patch or retry through another launcher" }
  finally { $process.Dispose() }
}

# Cleanup is best effort only after a transaction is committed or restored.
# Never bypass a host deletion guard or retry a denied deletion in finally.
function Remove-CompletedStage([string]$Path) {
  try { Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop }
  catch { Write-Output "cleanup_status: pending; completed transaction files were retained. Host cleanup permission is required; do not delete unknown directories or reinstall solely for this warning." }
}

function Test-InstallationEntry([string]$Path) {
  return $null -ne (Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue)
}

function Test-ManagedSkill([string]$Directory, [string]$Name) {
  $manifest = Join-Path $Directory "skill.json"
  if (-not (Test-Path -LiteralPath (Join-Path $Directory "SKILL.md") -PathType Leaf) -or -not (Test-Path -LiteralPath $manifest -PathType Leaf)) { return $false }
  try { return ((Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json).name -eq $Name) } catch { return $false }
}

function Test-LegacyNodeRuntime([string]$Directory) {
  $manifest = Join-Path $Directory "runtime.json"
  if (-not (Test-Path -LiteralPath (Join-Path $Directory "puretokens-direct-api.mjs") -PathType Leaf) -or -not (Test-Path -LiteralPath $manifest -PathType Leaf)) { return $false }
  try { return ((Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json).name -eq "puretokens-direct-api-runtime") } catch { return $false }
}

function Test-ManagedExecutor([string]$Directory) {
  $manifest = Join-Path $Directory "runtime.json"
  return (Test-Path -LiteralPath (Join-Path $Directory "puretokens-api.exe") -PathType Leaf) -and (Test-Path -LiteralPath $manifest -PathType Leaf) -and ((Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json).name -eq "puretokens-api-executor")
}

function Assert-OwnedInstallation([string]$Directory, [string]$Name, [string]$SourceDirectory = "") {
  $options = @("install-verify", "--directory", $Directory, "--name", $Name)
  if ($SourceDirectory) { $options += @("--source-directory", $SourceDirectory) }
  $result = Invoke-NativeExecutor $script:ownershipGuard $options
  if ($result.ExitCode -ne 0) { Fail "installation ownership or file changes require review: $Name; existing files were preserved" }
}

function Get-ExecutorPlatform() {
  $architecture = [System.Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString().ToLowerInvariant()
  switch ($architecture) {
    "x64" { return "windows-amd64" }
    "arm64" { return "windows-arm64" }
    default { Fail "no Pure Tokens executor is available for this operating system and CPU" }
  }
}

function Get-ExecutorArtifact([string]$SourceRoot) {
  $manifestPath = Join-Path $SourceRoot "runtime\executor\manifest.json"
  if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { Fail "official source is missing the executor manifest" }
  try { $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { Fail "official source executor manifest is invalid" }
  $platform = Get-ExecutorPlatform
  $artifact = $manifest.artifacts.PSObject.Properties[$platform].Value
  if ($null -eq $artifact -or [string]::IsNullOrWhiteSpace($artifact.path) -or [string]::IsNullOrWhiteSpace($artifact.sha256)) { Fail "official source is missing the executor artifact for $platform" }
  $binary = Join-Path (Join-Path $SourceRoot "runtime\executor") $artifact.path
  if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) { Fail "official source is missing the executor binary for $platform" }
  $actualHash = (Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actualHash -ne $artifact.sha256.ToLowerInvariant()) { Fail "official source executor checksum mismatch for $platform" }
  return $binary
}

function Get-SourceVersion([string]$SourceRoot) {
  try {
    $version = (Get-Content -LiteralPath (Join-Path $SourceRoot "package.json") -Raw -Encoding UTF8 | ConvertFrom-Json).version
    if ($version -notmatch '^\d+\.\d+\.\d+$') { Fail "official source has an invalid Skill version" }
    return $version
  } catch { Fail "official source has an invalid Skill version" }
}

function Test-OfficialSource([string]$SourceRoot) {
  if (-not (Test-Path -LiteralPath (Join-Path $SourceRoot "README.md") -PathType Leaf)) { Fail "official source is missing README.md" }
  if (-not (Test-Path -LiteralPath (Join-Path $SourceRoot "package.json") -PathType Leaf)) { Fail "official source is missing package.json" }
  $null = Get-SourceVersion $SourceRoot
  if (-not (Test-Path -LiteralPath (Join-Path $SourceRoot "runtime\puretokens-skill-install.ps1") -PathType Leaf)) { Fail "official source is missing the Windows installer" }
  if (-not (Test-Path -LiteralPath (Join-Path $SourceRoot "runtime\puretokens-skill-fetch.ps1") -PathType Leaf)) { Fail "official source is missing the download wrapper" }
  $null = Get-ExecutorArtifact $SourceRoot
  if (-not (Test-Path -LiteralPath (Join-Path $SourceRoot "runtime\puretokens-skill-install.sh") -PathType Leaf)) { Fail "official source is missing the macOS/Linux installer" }
  foreach ($name in $currentSkills) {
    if (-not (Test-ManagedSkill (Join-Path (Join-Path $SourceRoot "skills") $name) $name)) { Fail "official source has an invalid Skill: $name" }
  }
}

function Test-InstalledTarget([string]$TargetRoot) {
  if (-not (Test-Path -LiteralPath $TargetRoot -PathType Container)) { Fail "target Skill directory does not exist: $TargetRoot" }
  foreach ($name in $currentSkills) {
    if (-not (Test-ManagedSkill (Join-Path $TargetRoot $name) $name)) { Fail "target is missing the managed Skill: $name" }
  }
  if (-not (Test-ManagedExecutor (Join-Path $TargetRoot ".puretokens-executor"))) { Fail "target is missing the managed native executor" }
}

function Show-UsageGuide([string]$TargetRoot) {
  $guide = Join-Path (Join-Path $TargetRoot "puretokens-update") "references\usage-guide.md"
  if (Test-Path -LiteralPath $guide -PathType Leaf) {
    Get-Content -LiteralPath $guide -Raw -Encoding UTF8 | Write-Output
  } else {
    Write-Output "Pure Tokens Skill usage guide is unavailable; update the Skills from the official repository."
  }
}

function Invoke-Init([string]$TargetRoot, [string]$RequestedHost) {
  Test-InstalledTarget $TargetRoot
  if ([string]::IsNullOrWhiteSpace($RequestedHost)) {
    Write-Output "Pure Tokens Skill init: host ID was not supplied, so the connection check was deferred."
  } else {
    $executor = Join-Path (Join-Path $TargetRoot ".puretokens-executor") "puretokens-api.exe"
    $result = Invoke-NativeExecutor $executor @("init", "--host", $RequestedHost)
    $initOutput = @($result.Output)
    $json = $null
    if ($initOutput.Count -gt 0) {
      try { $json = ($initOutput -join "`n") | ConvertFrom-Json } catch { $json = $null }
    }
    if ($null -ne $json -and $json.configuration_status -eq "verified") {
      Write-Output "Pure Tokens Skill init: fixed API identity verified for the current host."
    } elseif ($null -ne $json) {
      $state = if ([string]::IsNullOrWhiteSpace($json.configuration_status)) { "unverified" } else { $json.configuration_status }
      $message = if ([string]::IsNullOrWhiteSpace($json.message)) { "The fixed API identity is not verified in this host session." } else { $json.message }
      Write-Output "Pure Tokens Skill init: $message [$state]"
      if ($null -ne $json.http_status -and [int]$json.http_status -gt 0) {
        Write-Output "HTTP status: $($json.http_status)"
      }
      if (-not [string]::IsNullOrWhiteSpace($json.next_action)) {
        Write-Output "Next: $($json.next_action)"
      }
    } else {
      Write-Output "Pure Tokens Skill init: configuration could not be checked in this host session."
    }
  }
  Write-Output ""
  Show-UsageGuide $TargetRoot
}

function Get-TargetForHost([string]$RequestedHost) {
  if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) { Fail "cannot resolve a host Skill directory because USERPROFILE is unavailable" }
  switch ($RequestedHost) {
    "claude-code" { if ($env:CLAUDE_CONFIG_DIR) { return (Join-Path $env:CLAUDE_CONFIG_DIR "skills") }; return (Join-Path $env:USERPROFILE ".claude\skills") }
    "claude-desktop" { if ($env:CLAUDE_CONFIG_DIR) { return (Join-Path $env:CLAUDE_CONFIG_DIR "skills") }; return (Join-Path $env:USERPROFILE ".claude\skills") }
    "kimi-code" {
      if ($env:KIMI_CODE_HOME) { return (Join-Path $env:KIMI_CODE_HOME "skills") }
      return (Join-Path $env:USERPROFILE ".kimi-code\skills")
    }
    "qoder" {
      if ($env:QODER_CONFIG_DIR) { return (Join-Path $env:QODER_CONFIG_DIR "skills") }
      $qoderName = ".qoder"
      if ($env:QODER_CONFIG_DIR_NAME) { $qoderName = $env:QODER_CONFIG_DIR_NAME }
      if ($qoderName -eq "." -or $qoderName -eq ".." -or $qoderName.Contains("/") -or $qoderName.Contains("\")) { Fail "invalid Qoder directory name" }
      $qoderBase = $env:USERPROFILE
      if ($env:QODER_CLI_HOME) { $qoderBase = $env:QODER_CLI_HOME }
      return (Join-Path (Join-Path $qoderBase $qoderName) "skills")
    }
    "zcode" {
      if ($env:ZCODE_DATA_BASE_DIR) {
        if (-not [System.IO.Path]::IsPathRooted($env:ZCODE_DATA_BASE_DIR)) { Fail "ZCode data directory must be absolute" }
        return (Join-Path $env:ZCODE_DATA_BASE_DIR ".zcode\skills")
      }
      return (Join-Path $env:USERPROFILE ".zcode\skills")
    }
    "dsh-desktop" {
      if ($env:DSH_HOME) { return (Join-Path $env:DSH_HOME "skills") }
      if (-not $env:APPDATA -or -not [System.IO.Path]::IsPathRooted($env:APPDATA)) { throw "DSH Desktop application directory is unavailable" }
      return (Join-Path $env:APPDATA "dsh-desktop\harness\skills")
    }
    "codex" { return (Join-Path $env:USERPROFILE ".agents\skills") }
    "workbuddy" { if ($env:WORKBUDDY_CONFIG_DIR) { return (Join-Path $env:WORKBUDDY_CONFIG_DIR "skills") }; if ($env:CODEBUDDY_CONFIG_DIR) { return (Join-Path $env:CODEBUDDY_CONFIG_DIR "skills") }; return (Join-Path $env:USERPROFILE ".workbuddy\skills") }
    "gemini-cli" {
      $shared = Join-Path $env:USERPROFILE ".agents\skills"
      foreach ($skill in $currentSkills) { if (Test-Path -LiteralPath (Join-Path $shared $skill)) { return $shared } }
      return (Join-Path $env:USERPROFILE ".gemini\skills")
    }
    "grok-build" { return (Join-Path $env:USERPROFILE ".grok\skills") }
    "opencode" { return (Join-Path $env:USERPROFILE ".config\opencode\skills") }
    "trae" { return (Join-Path $env:USERPROFILE ".trae\skills") }
    default { Fail "unsupported host: $RequestedHost" }
  }
}

function Test-GeminiDuplicates([string]$TargetRoot) {
  if ($HostId -ne "gemini-cli") { return }
  $shared = [IO.Path]::GetFullPath((Join-Path $env:USERPROFILE ".agents\skills")).TrimEnd('\')
  $isShared = [string]::Equals($TargetRoot.TrimEnd('\'), $shared, [StringComparison]::OrdinalIgnoreCase)
  foreach ($skill in $currentSkills) {
    if (-not $isShared -and (Test-Path -LiteralPath (Join-Path $shared $skill))) {
      Fail "Gemini would load $skill from its higher-priority .agents/skills directory. Run sync -Host gemini-cli without a custom target; existing directories were left untouched"
    }
    if ($isShared -and (Test-ManagedSkill (Join-Path (Join-Path $env:USERPROFILE ".gemini\skills") $skill) $skill)) {
      Write-Output "Managed duplicate detected: Gemini will use the updated shared $skill; its lower-priority .gemini copy was left untouched."
    }
  }
}

function Restore-Transaction([string]$TargetRoot, [string]$StageRoot) {
  $planFile = Join-Path $StageRoot "plan.json"
  if (-not (Test-Path -LiteralPath $planFile)) { return }
  foreach ($entry in @(Get-Content -LiteralPath $planFile -Raw -Encoding UTF8 | ConvertFrom-Json)) {
    if ($entry.name -notin ($currentSkills + @(".puretokens-executor"))) { Fail "unknown recovery entry; retained backup" }
    $destination = Join-Path $TargetRoot $entry.name
    $backup = Join-Path (Join-Path $StageRoot "backup") $entry.name
    if ($entry.action -eq "replace" -and (Test-Path -LiteralPath $backup)) {
      if (Test-InstallationEntry $destination) {
        Assert-OwnedInstallation $destination $entry.name (Join-Path (Join-Path $sourceRoot "skills") $entry.name)
        Remove-Item -LiteralPath $destination -Recurse -Force
      }
      Move-Item -LiteralPath $backup -Destination $destination
    } elseif ($entry.action -eq "create" -and -not (Test-Path -LiteralPath (Join-Path $StageRoot $entry.name))) {
      if (Test-InstallationEntry $destination) {
        Assert-OwnedInstallation $destination $entry.name (Join-Path (Join-Path $sourceRoot "skills") $entry.name)
        Remove-Item -LiteralPath $destination -Recurse -Force
      }
    }
  }
}

function Remove-LegacyCodexPlugin([string]$TargetRoot) {
  $codexTarget = [System.IO.Path]::GetFullPath((Join-Path $env:USERPROFILE ".agents\skills")).TrimEnd('\\')
  if (-not [string]::Equals($TargetRoot.TrimEnd('\\'), $codexTarget, [System.StringComparison]::OrdinalIgnoreCase)) { return }
  $codex = Get-Command codex -ErrorAction SilentlyContinue
  if ($null -eq $codex) { Write-Output "Legacy Codex plugin check unavailable. If old Puretokens Media instructions appear, remove that plugin in Codex Plugins and restart Codex."; return }
  try {
    $pluginOutput = & $codex.Source plugin list --json 2>$null
    if ($LASTEXITCODE -ne 0) { throw "plugin list failed" }
    $plugins = ($pluginOutput -join "`n") | ConvertFrom-Json
    $legacyPlugin = @($plugins.installed | Where-Object { $_.name -eq "puretokens-media" })
  } catch { Write-Output "Legacy Codex plugin inspection unavailable; check Codex Plugins only if old Media instructions remain."; return }
  if ($legacyPlugin.Count -eq 0) { return }
  foreach ($plugin in $legacyPlugin) {
    $selector = if (-not [string]::IsNullOrWhiteSpace($plugin.pluginId)) { $plugin.pluginId } elseif (-not [string]::IsNullOrWhiteSpace($plugin.marketplaceName)) { "$($plugin.name)@$($plugin.marketplaceName)" } else { $plugin.name }
    & $codex.Source plugin remove $selector --json *> $null
    if ($LASTEXITCODE -ne 0) { Fail "could not remove legacy Codex plugin $selector; remove it in Codex Plugins, then run this installer again" }
  }
  try {
    $pluginOutput = & $codex.Source plugin list --json 2>$null
    if ($LASTEXITCODE -ne 0) { throw "plugin list failed" }
    $plugins = ($pluginOutput -join "`n") | ConvertFrom-Json
    $legacyPlugin = @($plugins.installed | Where-Object { $_.name -eq "puretokens-media" })
  } catch { Fail "could not verify removal of legacy Codex plugin puretokens-media" }
  if ($legacyPlugin.Count -ne 0) { Fail "legacy Codex plugin puretokens-media is still installed; remove it in Codex Plugins, then run this installer again" }
  Write-Output "Removed and verified legacy Codex plugin puretokens-media. Fully restart Codex before testing the new Skills."
}

$stageRoot = $null
$updateLock = $null
try {
  if ([string]::IsNullOrWhiteSpace($Target) -and [string]::IsNullOrWhiteSpace($HostId)) { Fail "-Host or -Target is required" }
  if ([string]::IsNullOrWhiteSpace($Target)) { $Target = Get-TargetForHost $HostId }
  if (-not [System.IO.Path]::IsPathRooted($Target)) { Fail "-Target must be an absolute Skill directory" }
  if ($Command -eq "locate") { Write-Output $Target; exit 0 }

  if ($Command -eq "init") {
    $targetRoot = (Resolve-Path -LiteralPath $Target).Path
    Invoke-Init $targetRoot $HostId
    exit 0
  }

  if (-not [string]::IsNullOrWhiteSpace($Source)) {
    if (-not [System.IO.Path]::IsPathRooted($Source)) { Fail "-Source must be an absolute official source directory" }
    if (-not (Test-Path -LiteralPath $Source -PathType Container)) { Fail "-Source does not exist: $Source" }
    $sourceRoot = (Resolve-Path -LiteralPath $Source).Path
  } else {
    $bundledSourceRoot = Split-Path -Parent $PSScriptRoot
    if ((Test-Path -LiteralPath (Join-Path $bundledSourceRoot "README.md") -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $bundledSourceRoot "package.json") -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $bundledSourceRoot "skills") -PathType Container)) {
      $sourceRoot = $bundledSourceRoot
    } else { Fail "run this source-only sync script from a fresh official Pure Tokens Skills main checkout or pass -Source <absolute-checkout-directory>" }
  }
  Test-OfficialSource $sourceRoot
  if ($Command -eq "check") { Write-Output "Official Pure Tokens Skill source passed native static validation."; exit 0 }
  $releaseVersion = Get-SourceVersion $sourceRoot

  New-Item -ItemType Directory -Path $Target -Force | Out-Null
  $targetRoot = (Resolve-Path -LiteralPath $Target).Path
  Test-GeminiDuplicates $targetRoot
  $script:ownershipGuard = Get-ExecutorArtifact $sourceRoot
  try { $updateLock = [System.IO.File]::Open((Join-Path $targetRoot ".puretokens-install.lock"), [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None) } catch { Fail "another update is in progress or the update lock is not writable" }
  foreach ($previous in @(Get-ChildItem -LiteralPath $targetRoot -Directory -Force | Where-Object { $_.Name -like ".puretokens-skill-stage-*" })) {
    if (-not (Test-Path -LiteralPath (Join-Path $previous.FullName "transaction-v1"))) { Fail "unknown staging directory; left untouched" }
    if (-not (Test-Path -LiteralPath (Join-Path $previous.FullName "committed"))) { Restore-Transaction $targetRoot $previous.FullName }
    Remove-CompletedStage $previous.FullName
  }
  # Recheck after obtaining the installation lock: another sync may have
  # completed while this version's archive was still downloading.
  if (Test-ManagedExecutor (Join-Path $targetRoot ".puretokens-executor")) {
    $installedVersion = (Get-Content -LiteralPath (Join-Path $targetRoot ".puretokens-executor/runtime.json") -Raw -Encoding UTF8 | ConvertFrom-Json).version
    if ($installedVersion -notmatch '^\d+\.\d+\.\d+$') { Fail "installed executor version is invalid; left untouched" }
    if ([version]$installedVersion -gt [version]$releaseVersion) { Fail "a newer executor version is already installed; downgrade was stopped under the update lock" }
  }
  foreach ($name in $retiredSkills) {
    $destinations = @((Join-Path $targetRoot $name))
    $destinations += @(Get-ChildItem -LiteralPath $targetRoot -Force | Where-Object { $_.Name -like ("." + $name + ".retired-*") } | ForEach-Object { $_.FullName })
    foreach ($destination in $destinations) { if (Test-InstallationEntry $destination) { Assert-OwnedInstallation $destination $name } }
  }
  foreach ($name in $currentSkills) {
    $destination = Join-Path $targetRoot $name
    if (Test-InstallationEntry $destination) { Assert-OwnedInstallation $destination $name (Join-Path (Join-Path $sourceRoot "skills") $name) }
  }
  $executorDestination = Join-Path $targetRoot ".puretokens-executor"
  if (Test-InstallationEntry $executorDestination) { Assert-OwnedInstallation $executorDestination ".puretokens-executor" }

  $stageRoot = Join-Path $targetRoot (".puretokens-skill-stage-" + [Guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path (Join-Path $stageRoot "backup") -Force | Out-Null
  New-Item -ItemType File -Path (Join-Path $stageRoot "transaction-v1") | Out-Null
  foreach ($name in $currentSkills) { Copy-Item -LiteralPath (Join-Path (Join-Path $sourceRoot "skills") $name) -Destination $stageRoot -Recurse }
  $executorSource = Get-ExecutorArtifact $sourceRoot
  $stageExecutor = Join-Path $stageRoot ".puretokens-executor"
  New-Item -ItemType Directory -Path $stageExecutor -Force | Out-Null
  Copy-Item -LiteralPath $executorSource -Destination (Join-Path $stageExecutor "puretokens-api.exe")
  foreach ($script in @("puretokens-skill-install.ps1", "puretokens-skill-fetch.ps1")) {
    Copy-Item -LiteralPath (Join-Path (Join-Path $sourceRoot "runtime") $script) -Destination $stageExecutor
  }
  [PSCustomObject]@{ schemaVersion = 1; name = "puretokens-api-executor"; version = $releaseVersion; platform = (Get-ExecutorPlatform) } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stageExecutor "runtime.json") -Encoding utf8
  foreach ($name in ($currentSkills + @(".puretokens-executor"))) {
    $directory = Join-Path $stageRoot $name
    $result = Invoke-NativeExecutor $script:ownershipGuard @("install-inventory", "--directory", $directory, "--name", $name)
    $inventory = $result.Output
    if ($result.ExitCode -ne 0) { Fail "could not record managed files for $name" }
    $inventory | Set-Content -LiteralPath (Join-Path $directory ".puretokens-managed.json") -Encoding UTF8
  }

  Remove-LegacyCodexPlugin $targetRoot
  $plan = @()
  foreach ($name in ($currentSkills + @(".puretokens-executor"))) {
    $action = if (Test-InstallationEntry (Join-Path $targetRoot $name)) { "replace" } else { "create" }
    $plan += [PSCustomObject]@{ name = $name; action = $action }
  }
  $plan | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stageRoot "plan.json") -Encoding utf8
  foreach ($entry in $plan) {
    $destination = Join-Path $targetRoot $entry.name
    if ($entry.action -eq "replace") {
      Assert-OwnedInstallation $destination $entry.name (Join-Path (Join-Path $sourceRoot "skills") $entry.name)
      Move-Item -LiteralPath $destination -Destination (Join-Path (Join-Path $stageRoot "backup") $entry.name)
    } elseif (Test-InstallationEntry $destination) { Fail "a destination appeared during installation; existing files were preserved" }
    Move-Item -LiteralPath (Join-Path $stageRoot $entry.name) -Destination $destination
  }
  # Require the inventory itself, even if install-verify could adopt an exact source copy.
  foreach ($name in ($currentSkills + @(".puretokens-executor"))) {
    $installed = Join-Path $targetRoot $name
    if (-not (Test-Path -LiteralPath (Join-Path $installed ".puretokens-managed.json") -PathType Leaf)) { Fail "managed inventory missing; installation is incomplete" }
    $result = Invoke-NativeExecutor $script:ownershipGuard @("install-verify", "--directory", $installed, "--name", $name)
    if ($result.ExitCode -ne 0) { Fail "installed managed files could not be verified" }
  }
  New-Item -ItemType File -Path (Join-Path $stageRoot "committed") | Out-Null
  foreach ($name in $retiredSkills) {
    $destinations = @((Join-Path $targetRoot $name))
    $destinations += @(Get-ChildItem -LiteralPath $targetRoot -Force | Where-Object { $_.Name -like ("." + $name + ".retired-*") } | ForEach-Object { $_.FullName })
    foreach ($destination in $destinations) { if (Test-Path -LiteralPath $destination) { Assert-OwnedInstallation $destination $name; Remove-Item -LiteralPath $destination -Recurse -Force; Write-Output "Removed retired managed $name from $destination" } }
  }
  $legacyRuntime = Join-Path $targetRoot ".puretokens-runtime"
  if ((Test-Path -LiteralPath $legacyRuntime) -and (Test-LegacyNodeRuntime $legacyRuntime)) {
    $result = Invoke-NativeExecutor $script:ownershipGuard @("install-verify", "--directory", $legacyRuntime, "--name", ".puretokens-runtime")
    if ($result.ExitCode -eq 0) {
      Remove-Item -LiteralPath $legacyRuntime -Recurse -Force
      Write-Output "Removed retired managed Node runtime from $legacyRuntime"
    } else { Write-Output "Unverified or modified legacy runtime preserved; review it separately." }
  }
  Write-Output "Pure Tokens Skills $releaseVersion synchronized with the native API executor at $targetRoot"
  Remove-CompletedStage $stageRoot
  $stageRoot = $null
  $updateLock.Dispose(); $updateLock = $null
  Invoke-Init $targetRoot $HostId
} finally {
  try {
    if ($null -ne $stageRoot -and (Test-Path -LiteralPath $stageRoot)) {
      if (-not (Test-Path -LiteralPath (Join-Path $stageRoot "committed"))) { Restore-Transaction $targetRoot $stageRoot }
      Remove-CompletedStage $stageRoot
    }
  } finally { if ($null -ne $updateLock) { $updateLock.Dispose() } }
}
